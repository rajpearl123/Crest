<?php

namespace Mpdf\Tag;

class Mark extends InlineTag
{


}
