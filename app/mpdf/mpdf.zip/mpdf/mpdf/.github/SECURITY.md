How to disclose potential security issues
============

As mPDF does not have a domain or a dedicated contact apart from its Github repository, to prevent 
disclosing maintainers' contacts publicly, please use [GitHub's Security Advisories system](https://github.com/mpdf/mpdf/security/advisories).